export class UserService {
  user = {
    name: 'Admin'
  };
}
