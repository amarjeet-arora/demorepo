import { Component } from '@angular/core';

@Component({
    moduleId: module.id,
    selector: 'mycm',
    templateUrl: 'mycm.component.html',
    styleUrls: ['mycm.component.scss']
})
export class MycmComponent {

}
