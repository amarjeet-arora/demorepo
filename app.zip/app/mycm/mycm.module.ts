// Angular Imports
import { NgModule } from '@angular/core';

// This Module's Components
import { MycmComponent } from './mycm.component';

@NgModule({
    imports: [

    ],
    declarations: [
        MycmComponent,
    ],
    exports: [
        MycmComponent,
    ]
})
export class MycmModule {

}
